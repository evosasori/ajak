<!-- <br><br><button id="addButton" class="btn btn-success">Tambah Data <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
</svg></button> -->
<br><br><button id="tambahbtn" class="btn btn-success tambah" onclick="tgh()">Tambah Data <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
</svg></button>
<br>
<br>
<div class="container">
<table border="1" class="table table-warning table-striped">
    <thead>
        <tr>
            <th scope="col">No.</th>
            <th scope="col">Nama</th>
            <th scope="col">Jenis Kelamin</th>
            <th scope="col">Alamat</th>
            <th scope="col">Agama</th>
            <th scope="col">No. HP</th>
            <th scope="col">Email</th>
            <th scope="col">Aksi</th>
        </tr>
    </thead>
    <tbody>
<?php
    $koneksi = mysqli_connect("localhost", "root", "", "akademik");
   $no=1;
   $query=mysqli_query($koneksi, "SELECT * FROM Mahasiswa ORDER BY IdMhsw DESC") or die(mysqli_error($koneksi));
   while ($result=mysqli_fetch_array($query)) {
    ?>
            <tr>
                <td scope="row">
                    <?php echo $no++; ?>
                </td>
                <td scope="row">
                    <?php echo $result['Nama']; ?>
                </td>
                <td scope="row">
                    <?php echo $result['JenisKelamin']; ?>
                </td>
                <td scope="row">
                    <?php echo $result['Alamat']; ?>
                </td>
                <td scope="row">
                    <?php echo $result['Agama']; ?>
                </td>
                <td scope="row">
                    <?php echo $result['NoHp']; ?>
                </td>
                <td scope="row">
                    <?php echo $result['Email']; ?>
                </td>
                <td scope="row">
                    <button id="EditButton" class="btn" value="<?php echo $result['IdMhsw']; ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
  <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
</svg></button>
                    <button id="DeleteButton" class="btn" value="<?php echo $result['IdMhsw']; ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
</svg></button>
                </td>
            </tr>
            <?php
   }
  ?>
    </tbody>
</table>
</div><br><br>
<div style="width: 40%;" class="display d-none">
<h3 class="display1 d-none" id="tambah">Tambah Data</h3>
<form method="POST" id="formAdd">
<label for="Nama" class="form-label"><b>Nama</b></label>
<input type="text" name="Nama" class="form-control" id="Nama" required="" /><br>
<label class="form-label"><b>Jenis Kelamin</b></label><br>
<label>
<input type="radio" class="form-check-input" name="JenisKelamin" id="JenisKelamin" value="Laki-laki" required="" /> Laki-laki</label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<label>
<input type="radio" class="form-check-input" name="JenisKelamin" id="JenisKelamin" value="Perempuan" required="" /> Perempuan</label><br><br>
<label for="Alamat" class="form-label"><b>Alamat</b></label>
<textarea class="form-control" name="Alamat" id="Alamat" required=""></textarea>

<label for="Agama" class="form-label"><b>Agama</b></label>
<select class="form-select" name="Agama" id="Agama" required="">
<option disabled="" selected="">-Pilih-</option>
<option value="Islam">Islam</option>
<option value="Kristen">Kristen</option>
<option value="Katholik">Katholik</option>
<option value="Budha">Budha</option>
<option value="Hindhu">Hindhu</option>
<option value="Konghucu">Konghucu</option>
<option value="Lain-lain">Lain-lain</option>
</select>
<label for="NoHP" class="form-label"><b>No.Hp</b></label>
<input type="text" class="form-control" name="NoHP" id="NoHP" required="" />
<label for="Email" class="form-label"><b>Email</b></label>
<input type="email" class="form-control" name="Email" id="Email" required="" /><br><br>
<div class="container text-center">
  <div class="row">
    <div class="col-sm-5 col-md-6">
      <div class="d-grid gap-2">
  <button type="submit" class="btn btn-success" name="simpan" id="simpan">Simpan</button>
</div></div>
    <div class="col-sm-5 offset-sm-2 col-md-6 offset-md-0">
      <div class="d-grid gap-2">
  <button type="button" class="btn btn-secondary" onClick="tgh1()" width="200%">Batal</button>
</div></div>
</form></div><br><br>
  </div>