<!DOCTYPE html>
<html>
<head>
    <title>Data MHS</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script type="text/javascript" src="jquery.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {

            //load data mahasiswa saat aplikasi dijalankan 
            loadData();

            //Load form addF
            $("#contentData").on("click", "#addButton", function() {
                $.ajax({
                    url: '<?= base_url('form-add')  ?>',
                    type: 'get',
                    success: function(data) {
                        $('#contentData').html(data);
                    }
                });
            });

            //Load form edit dengan parameter IdMhsw
            $("#contentData").on("click", "#EditButton", function() {
                var IdMhsw = $(this).attr("value");
                $.ajax({
                    url: '<?= base_url('form-edit')  ?>',
                    type: 'get',
                    data: {
                        IdMhsw: IdMhsw
                    },
                    success: function(data) {
                        $('#contentData').html(data);
                    }
                });
            });

            //button batal
            $("#contentData").on("click", "#cancelButton", function() {
                loadData1();
            });

            //simpan data mahasiswa
            $("#contentData").on("submit", "#formAdd", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'service.php?action=save',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadData();
                    }
                });
            });

            //edit data mahasiswa
            $("#contentData").on("submit", "#formEdit", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'service.php?action=edit',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadData();
                    }
                });
            });

            //hapus data mahasiswa berdasarkan IdMhsw
            $("#contentData").on("click", "#DeleteButton", function() {
                var IdMhsw = $(this).attr("value");
                $.ajax({
                    url: 'service.php?action=delete',
                    type: 'post',
                    data: {
                        IdMhsw: IdMhsw
                    },
                    success: function(data) {
                        alert(data);
                        loadData();
                    }
                });
            });
        })

        function loadData() {
            $.ajax({
                url: '<?= base_url('data-mahasiswa')  ?>',
                type: 'get',
                success: function(data) {
                    $('#contentData').html(data);
                    // setTimeout(loadData,10000);
                }
            });
        }
                function loadData1() {
            $.ajax({
                url: '<?= base_url('data-mahasiswa')  ?>',
                type: 'get',
                success: function(data) {
                    $('#contentData').html(data);
                    setTimeout(loadData,5000);
                }
            });
        }

function tgh() {
    // loadData();
    const display = document.querySelector('.display');
    const tbh = document.querySelector('.tambah');
    const display1 = document.querySelector('.display1');
    display.classList.toggle('d-none');   
    display1.classList.toggle('d-none'); 
    tbh.classList.toggle('d-none'); 
    window.location.href = '#tambah';  
}
function tgh1() {
    const display = document.querySelector('.display');
    const tbh = document.querySelector('.tambah');
    const display1 = document.querySelector('.display1');
    display.classList.toggle('d-none');   
    display1.classList.toggle('d-none'); 
    tbh.classList.toggle('d-none'); 
    window.location.href = '#tambah';  
    loadData1();
}
    </script>
</head>
<body>
    <div align="center">
        <br>
        <h2>Data Siswa</h2>
        <div id="contentData"></div>
    </div>
</body>

</html>