<?php

namespace App\Controllers;

class Home extends BaseController
{

    public function index()
    {
        return view('index');
    }
    public function dataM()
    {
    	return view('data-mahasiswa');
    }
    public function formA()
    {
    	return view('form-add');
    }
        public function formE()
    {
    	return view('form-edit');
    }
        public function ser()
    {
    	return view('service');
    }
    public function sersave()
    {
    	$koneksi = mysqli_connect("localhost", "root", "", "akademik");
    	$Nama = $_POST['Nama'];
        $JenisKelamin = $_POST['JenisKelamin'];
        $Alamat = $_POST['Alamat'];
        $Agama = $_POST['Agama'];
        $NoHP = $_POST['NoHP'];
        $Email = $_POST['Email'];
        $query = mysqli_query($koneksi, "INSERT INTO Mahasiswa(Nama, JenisKelamin, Alamat, Agama, NoHp, Email) VALUES('$Nama', '$JenisKelamin', '$Alamat', '$Agama', '$NoHP', '$Email')");
        if ($query)
        {
            echo "Simpan Data Berhasil";
        }
        else
        {
            echo "Simpan Data Gagal :" . mysqli_error($koneksi);
        }
    }
}
